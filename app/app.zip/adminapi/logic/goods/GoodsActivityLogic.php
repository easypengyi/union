<?php
// +----------------------------------------------------------------------
// | likeshop100%开源免费商用商城系统
// +----------------------------------------------------------------------
// | 欢迎阅读学习系统程序代码，建议反馈是我们前进的动力
// | 开源版本可自由商用，可去除界面版权logo
// | 商业版本务必购买商业授权，以免引起法律纠纷
// | 禁止对系统程序代码以任何目的，任何形式的再发布
// | gitee下载：https://gitee.com/likeshop_gitee
// | github下载：https://github.com/likeshop-github
// | 访问官网：https://www.likeshop.cn
// | 访问社区：https://home.likeshop.cn
// | 访问手册：http://doc.likeshop.cn
// | 微信公众号：likeshop技术社区
// | likeshop团队 版权所有 拥有最终解释权
// +----------------------------------------------------------------------
// | author: likeshopTeam
// +----------------------------------------------------------------------

namespace app\adminapi\logic\goods;


use app\common\enum\DefaultEnum;
use app\common\enum\YesNoEnum;
use app\common\model\GoodsActivity;

class GoodsActivityLogic
{
    /**
     * @notes 添加商品分类
     * @param $params
     * @return bool
     * @author ljj
     * @date 2021/7/17 5:46 下午
     */
    public function add($params)
    {
        $GoodsActivity = new GoodsActivity;
        $GoodsActivity->id = $params['id'];
        $GoodsActivity->activity_type = $params['activity_type'];
        $GoodsActivity->activity_id = $params['activity_id'];
        $GoodsActivity->goods_id = $params['goods_id'];
        $GoodsActivity->item_id = $params['item_id'];
        $GoodsActivity->name = $params['name'];
        $GoodsActivity->description = isset($params['description']) ? $params['description'] : ' ';
        $GoodsActivity->startDate = $params['startDate'];
        $GoodsActivity->endDate = $params['endDate'];
        $GoodsActivity->brand = $params['brand'];
        $GoodsActivity->brandLogoUrl = isset($params['brandLogoUrl']) ? $params['brandLogoUrl'] : '';
        $GoodsActivity->statementByDay = $params['statementByDay'];
        $GoodsActivity->categoryId = $params['categoryId'];
        $GoodsActivity->category = $params['category'];
        $GoodsActivity->deliverTime = $params['deliverTime'];
        $GoodsActivity->content = $params['content'];
        $GoodsActivity->activeModel = $params['activeModel'];
        $GoodsActivity->aftersaleEndTime = $params['aftersaleEndTime'];
        $GoodsActivity->previewInformation = $params['previewInformation'];
        $GoodsActivity->refundInsurance = $params['refundInsurance'];
        $GoodsActivity->isExchangeRefundGoods = $params['isExchangeRefundGoods'];
        $GoodsActivity->activeType = $params['activeType'];
        $GoodsActivity->status = $params['status'];
        $GoodsActivity->banner = $params['banner'];

        return $GoodsActivity->save();
    }
    /**
     * @notes 获取当前时间内需要下载的商品
     * @return array
     * @author cjhao
     * @date 2021/7/26 10:41
     */
    public static function getActivityDownGoodsLists(array $ids = []):array
    {
        $where = [];
        if($ids){
            $where[] = ['C.id'=>$ids];
        }
        $where['is_down_goods'] =1;
        $list = GoodsActivity::where($where)->field("id")->select()->toArray();;
        return $list;
    }
    /**
     * @notes 修改商品品牌显示状态
     * @param $params
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     * @author ljj
     * @date 2021/7/15 11:41
     */
    public function status($params)
    {
   

        $GoodsActivity = new GoodsActivity;
        return $GoodsActivity::update(['id'=>$params['id'],'is_down_goods'=>$params['is_down_goods']]);

    }



}